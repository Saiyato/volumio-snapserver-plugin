#!/bin/bash

# Uninstall dependendencies
apt-get remove -y --purge snapserver

echo "Done"
echo "pluginuninstallend"